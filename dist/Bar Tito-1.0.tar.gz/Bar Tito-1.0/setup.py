from setuptools import setup

setup(
    name="Bar Tito",
    version="1.0",
    description="Log in de clientes del Bar",
    author="Nicolas Osa",
    author_email="osanicolas180@gmail.com",
    packages=["Segunda pre-entrega+Osa"]
)